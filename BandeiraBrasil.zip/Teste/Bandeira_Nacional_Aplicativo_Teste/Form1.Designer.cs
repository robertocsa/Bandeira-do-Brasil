﻿namespace Bandeira_Nacional_Aplicativo_Teste
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.ctl_BandeiraBrasil2 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.ctl_BandeiraBrasil10 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.ctl_BandeiraBrasil6 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.ctl_BandeiraBrasil7 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.ctl_BandeiraBrasil8 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.ctl_BandeiraBrasil9 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.ctl_BandeiraBrasil4 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.ctl_BandeiraBrasil5 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.ctl_BandeiraBrasil3 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.ctl_BandeiraBrasil1 = new BandeiraBrasil.Ctl_BandeiraBrasil();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.imprimirToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(160, 68);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(159, 32);
            this.imprimirToolStripMenuItem.Text = "Imprimir";
            this.imprimirToolStripMenuItem.Click += new System.EventHandler(this.imprimirToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(159, 32);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // printDialog1
            // 
            this.printDialog1.AllowPrintToFile = false;
            this.printDialog1.Document = this.printDocument1;
            this.printDialog1.UseEXDialog = true;
            // 
            // toolTip1
            // 
            this.toolTip1.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip1_Popup);
            // 
            // ctl_BandeiraBrasil2
            // 
            this.ctl_BandeiraBrasil2.Location = new System.Drawing.Point(167, 9);
            this.ctl_BandeiraBrasil2.Name = "ctl_BandeiraBrasil2";
            this.ctl_BandeiraBrasil2.Size = new System.Drawing.Size(1371, 960);
            this.ctl_BandeiraBrasil2.TabIndex = 11;
            this.toolTip1.SetToolTip(this.ctl_BandeiraBrasil2, "Para imprimir, utilize o botão direito do mouse...\r\n\r\n");
            // 
            // ctl_BandeiraBrasil10
            // 
            this.ctl_BandeiraBrasil10.Location = new System.Drawing.Point(12, 913);
            this.ctl_BandeiraBrasil10.Name = "ctl_BandeiraBrasil10";
            this.ctl_BandeiraBrasil10.Size = new System.Drawing.Size(141, 99);
            this.ctl_BandeiraBrasil10.TabIndex = 10;
            // 
            // ctl_BandeiraBrasil6
            // 
            this.ctl_BandeiraBrasil6.Location = new System.Drawing.Point(12, 800);
            this.ctl_BandeiraBrasil6.Name = "ctl_BandeiraBrasil6";
            this.ctl_BandeiraBrasil6.Size = new System.Drawing.Size(141, 99);
            this.ctl_BandeiraBrasil6.TabIndex = 9;
            // 
            // ctl_BandeiraBrasil7
            // 
            this.ctl_BandeiraBrasil7.Location = new System.Drawing.Point(12, 687);
            this.ctl_BandeiraBrasil7.Name = "ctl_BandeiraBrasil7";
            this.ctl_BandeiraBrasil7.Size = new System.Drawing.Size(141, 99);
            this.ctl_BandeiraBrasil7.TabIndex = 8;
            // 
            // ctl_BandeiraBrasil8
            // 
            this.ctl_BandeiraBrasil8.Location = new System.Drawing.Point(12, 574);
            this.ctl_BandeiraBrasil8.Name = "ctl_BandeiraBrasil8";
            this.ctl_BandeiraBrasil8.Size = new System.Drawing.Size(141, 99);
            this.ctl_BandeiraBrasil8.TabIndex = 7;
            // 
            // ctl_BandeiraBrasil9
            // 
            this.ctl_BandeiraBrasil9.Location = new System.Drawing.Point(12, 461);
            this.ctl_BandeiraBrasil9.Name = "ctl_BandeiraBrasil9";
            this.ctl_BandeiraBrasil9.Size = new System.Drawing.Size(141, 99);
            this.ctl_BandeiraBrasil9.TabIndex = 6;
            // 
            // ctl_BandeiraBrasil4
            // 
            this.ctl_BandeiraBrasil4.Location = new System.Drawing.Point(12, 348);
            this.ctl_BandeiraBrasil4.Name = "ctl_BandeiraBrasil4";
            this.ctl_BandeiraBrasil4.Size = new System.Drawing.Size(141, 99);
            this.ctl_BandeiraBrasil4.TabIndex = 5;
            // 
            // ctl_BandeiraBrasil5
            // 
            this.ctl_BandeiraBrasil5.Location = new System.Drawing.Point(12, 235);
            this.ctl_BandeiraBrasil5.Name = "ctl_BandeiraBrasil5";
            this.ctl_BandeiraBrasil5.Size = new System.Drawing.Size(141, 99);
            this.ctl_BandeiraBrasil5.TabIndex = 4;
            // 
            // ctl_BandeiraBrasil3
            // 
            this.ctl_BandeiraBrasil3.Location = new System.Drawing.Point(12, 122);
            this.ctl_BandeiraBrasil3.Name = "ctl_BandeiraBrasil3";
            this.ctl_BandeiraBrasil3.Size = new System.Drawing.Size(141, 99);
            this.ctl_BandeiraBrasil3.TabIndex = 3;
            // 
            // ctl_BandeiraBrasil1
            // 
            this.ctl_BandeiraBrasil1.Location = new System.Drawing.Point(12, 9);
            this.ctl_BandeiraBrasil1.Name = "ctl_BandeiraBrasil1";
            this.ctl_BandeiraBrasil1.Size = new System.Drawing.Size(141, 99);
            this.ctl_BandeiraBrasil1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1550, 1026);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.ctl_BandeiraBrasil2);
            this.Controls.Add(this.ctl_BandeiraBrasil10);
            this.Controls.Add(this.ctl_BandeiraBrasil6);
            this.Controls.Add(this.ctl_BandeiraBrasil7);
            this.Controls.Add(this.ctl_BandeiraBrasil8);
            this.Controls.Add(this.ctl_BandeiraBrasil9);
            this.Controls.Add(this.ctl_BandeiraBrasil4);
            this.Controls.Add(this.ctl_BandeiraBrasil5);
            this.Controls.Add(this.ctl_BandeiraBrasil3);
            this.Controls.Add(this.ctl_BandeiraBrasil1);
            this.Name = "Form1";
            this.Text = "Aplicativo para teste da biblioteca de função que desenha a Bandeira Nacional // " +
                "Program to test the user control library (DLL) that draws the Brazilian flag.";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem imprimirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil1;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil3;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil4;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil5;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil6;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil7;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil8;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil9;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil10;
        private BandeiraBrasil.Ctl_BandeiraBrasil ctl_BandeiraBrasil2;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.ToolTip toolTip1;
 
    }
}

